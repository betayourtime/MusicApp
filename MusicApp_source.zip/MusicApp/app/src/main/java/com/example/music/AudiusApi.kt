package com.example.music

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class AudiusApi {
    private val http = OkHttpClient.Builder()
        .callTimeout(20, TimeUnit.SECONDS)
        .build()

    private val base = "https://api.audius.co/v1"

    fun trending(): List<Track> = getTracks("$base/tracks/trending?limit=20")
    fun search(query: String): List<Track> {
        val q = URLEncoder.encode(query, "UTF-8")
        return getTracks("$base/tracks/search?query=$q&limit=25")
    }

    private fun getTracks(url: String): List<Track> {
        val request = Request.Builder()
            .url(url)
            .header("Accept", "application/json")
            .build()
        http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Audius вернул HTTP ${response.code}")
            val body = response.body?.string() ?: return emptyList()
            val arr = JSONObject(body).optJSONArray("data") ?: return emptyList()
            return (0 until arr.length()).mapNotNull { i ->
                val item = arr.optJSONObject(i) ?: return@mapNotNull null
                val user = item.optJSONObject("user")
                val artworkObj = item.optJSONObject("artwork")
                val artwork = artworkObj?.optString("150x150")
                    ?.takeIf { !it.isNullOrBlank() && it != "null" }
                val id = item.optString("id")
                if (id.isBlank()) return@mapNotNull null
                Track(
                    id = id,
                    title = item.optString("title", "Без названия"),
                    artist = user?.optString("name", "Неизвестный исполнитель") ?: "Неизвестный исполнитель",
                    artwork = artwork,
                    duration = item.optLong("duration", 0L),
                    streamUrl = "$base/tracks/$id/stream"
                )
            }
        }
    }
}
