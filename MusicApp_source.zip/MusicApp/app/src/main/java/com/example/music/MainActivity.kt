package com.example.music

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import coil.compose.AsyncImage
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF101010)
private val SurfaceDark = Color(0xFF202020)
private val Accent = Color(0xFFFFCC33)

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, MoreExecutors.directExecutor())

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = SurfaceDark, primary = Accent,
                onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
            )) {
                MusicHome(
                    context = this,
                    playTrack = { track ->
                        controller?.let { player ->
                            val metadata = MediaMetadata.Builder()
                                .setTitle(track.title)
                                .setArtist(track.artist)
                                .setArtworkUri(track.artwork?.let { android.net.Uri.parse(it) })
                                .build()
                            player.setMediaItem(MediaItem.Builder()
                                .setUri(track.streamUrl)
                                .setMediaMetadata(metadata)
                                .build())
                            player.prepare()
                            player.play()
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }
}

@Composable
fun MusicHome(context: Context, playTrack: (Track) -> Unit) {
    val api = remember { AudiusApi() }
    val scope = rememberCoroutineScope()
    var tracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf(0) }
    var localTracks by remember { mutableStateOf<List<Track>>(emptyList()) }
    var localMessage by remember { mutableStateOf("Открой доступ к аудиофайлам, чтобы увидеть музыку на телефоне.") }
    val audioPermission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    val localPermissionLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            localTracks = readLocalTracks(context)
            localMessage = if (localTracks.isEmpty()) "На устройстве пока не найдено аудиофайлов." else "Музыка с устройства"
        } else localMessage = "Нет разрешения на чтение аудиофайлов."
    }

    fun loadTrending() {
        loading = true
        error = null
        scope.launch {
            try {
                tracks = withContext(Dispatchers.IO) { api.trending() }
            } catch (e: Exception) {
                error = e.message ?: "Не удалось загрузить музыку"
            } finally { loading = false }
        }
    }

    LaunchedEffect(Unit) { loadTrending() }

    Column(Modifier.fillMaxSize().background(Bg)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("music", color = Accent, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.AccountCircle, contentDescription = "Профиль", tint = Color.White, modifier = Modifier.size(29.dp))
        }

        when (tab) {
            0 -> {
                Text("Твоя музыка начинается здесь", modifier = Modifier.padding(horizontal = 20.dp), color = Color.LightGray, fontSize = 14.sp)
                Text("Популярное сейчас", modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 10.dp), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                if (loading) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
                } else if (error != null) {
                    Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("Не получилось загрузить каталог", color = Color.White)
                        Text(error ?: "", color = Color.Gray, fontSize = 12.sp)
                        TextButton(onClick = { loadTrending() }) { Text("Повторить", color = Accent) }
                    }
                } else {
                    TrackList(tracks, playTrack)
                }
            }
            1 -> {
                Text("Поиск", modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 12.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    placeholder = { Text("Треки, исполнители") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = ""; loadTrending() }) { Icon(Icons.Default.Close, null) } },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Accent, unfocusedBorderColor = Color.DarkGray,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White
                    )
                )
                LaunchedEffect(query) {
                    if (query.isNotBlank()) {
                        kotlinx.coroutines.delay(450)
                        loading = true
                        try { tracks = withContext(Dispatchers.IO) { api.search(query) }; error = null }
                        catch (e: Exception) { error = e.message }
                        finally { loading = false }
                    }
                }
                if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
                else if (error != null) Text(error ?: "", color = Color.LightGray, modifier = Modifier.padding(20.dp))
                else TrackList(tracks, playTrack, Modifier.weight(1f))
            }
            else -> {
                Text("Моя коллекция", modifier = Modifier.padding(20.dp), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Локальная музыка", modifier = Modifier.padding(horizontal = 20.dp), color = Color.LightGray, fontWeight = FontWeight.SemiBold)
                Text(localMessage, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = Color.Gray, fontSize = 13.sp)
                Button(
                    onClick = {
                        if (ContextCompat.checkSelfPermission(context, audioPermission) == PackageManager.PERMISSION_GRANTED) {
                            localTracks = readLocalTracks(context)
                            localMessage = if (localTracks.isEmpty()) "На устройстве пока не найдено аудиофайлов." else "Музыка с устройства"
                        } else localPermissionLauncher.launch(audioPermission)
                    },
                    modifier = Modifier.padding(horizontal = 20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)
                ) { Text("Найти музыку на телефоне") }
                if (localTracks.isNotEmpty()) TrackList(localTracks, playTrack, Modifier.weight(1f))
                else Spacer(Modifier.weight(1f))
            }
        }

        NavigationBar(containerColor = Bg, contentColor = Color.White) {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Главная") }, colors = navColors())
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Поиск") }, colors = navColors())
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.LibraryMusic, null) }, label = { Text("Коллекция") }, colors = navColors())
        }
    }
}

@Composable
private fun navColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = Accent, selectedTextColor = Accent,
    indicatorColor = SurfaceDark, unselectedIconColor = Color.Gray, unselectedTextColor = Color.Gray
)

@Composable
fun TrackList(tracks: List<Track>, playTrack: (Track) -> Unit, modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(bottom = 12.dp)) {
        items(tracks, key = { it.id }) { track ->
            Row(
                Modifier.fillMaxWidth().clickable { playTrack(track) }.padding(horizontal = 16.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AsyncImage(
                    model = track.artwork, contentDescription = null,
                    modifier = Modifier.size(54.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceDark),
                    contentScale = ContentScale.Crop
                )
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(track.title, color = Color.White, maxLines = 1, fontWeight = FontWeight.SemiBold)
                    Text(track.artist, color = Color.Gray, maxLines = 1, fontSize = 13.sp)
                }
                Icon(Icons.Default.PlayCircle, contentDescription = "Слушать", tint = Accent, modifier = Modifier.size(28.dp))
            }
        }
    }
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
private fun readLocalTracks(context: Context): List<Track> {
    val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
    } else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.DURATION
    )
    val result = mutableListOf<Track>()
    context.contentResolver.query(
        collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    )?.use { cursor ->
        val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
        val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
        val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
        val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
        while (cursor.moveToNext()) {
            val id = cursor.getLong(idCol)
            val uri = ContentUris.withAppendedId(collection, id)
            result += Track(
                id = "local-$id",
                title = cursor.getString(titleCol) ?: "Без названия",
                artist = cursor.getString(artistCol) ?: "Неизвестный исполнитель",
                artwork = null,
                duration = cursor.getLong(durationCol),
                streamUrl = uri.toString()
            )
        }
    }
    return result
}
